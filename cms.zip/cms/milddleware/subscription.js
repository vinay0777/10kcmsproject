

// function subscription(req,res,next){
//     try{if(req.session.sub=='subscription'){
//         next()
//     }else{
//         res.send{"You are not subscribed with us to use this funcationlity"}
//     }
// }catch(error){
//     console.log(error.message)
//     }
// }

// module.exports=subscription 