const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const blogc=require('../controllers/blogcontroller')
const upload=require('../milddleware/multer')
const subscription = require('../milddleware/subscription')




router.get("/dashboard",(req,res)=>{
    res.render('admin/dashboard.ejs')
})




module.exports=router