const blogTable=require('../models/blog')

exports.allblogs=async(req,res)=>{
    const loginname1=req.session.loginname
    var fields=loginname1.split('@')
    const loginname=fields =fields[0]
    const data=await blogTable.find()
    res.render("allblogs.ejs",{loginname,data})
}

exports.myblogs=async(req,res)=>{
    const message=req.params.mess
    const loginname=req.session.loginname
    const data=await blogTable.find({user:loginname})
    res.render('myblogs.ejs',{loginname,message,data})
}

exports.blogform=(req,res)=>{
    const loginname=req.session.loginname
    res.render('blogform.ejs',{loginname})
}

exports.blogadd=(req,res)=>{
    const loginname=req.session.loginname
    const{title,desc}=req.body
    if(req.file){
        const filename=req.file.filename
    var newData=new blogTable({title:title,quotes:desc,user:loginname,img:filename})
}else{
    var newData=new blogTable({title:title,quotes:desc,user:loginname,img:'defalt.jpg'})
}
    newData.save()
    // console.log(newData)
    res.redirect('/myblogs/Successfully has been Added')
}


exports.blogdelete=async(req,res)=>{
    const id=req.params.id
    await blogTable.findByIdAndDelete(id)
    res.redirect(`/myblogs/Successfully has been Delete`)
} 

exports.blogupdate=async(req,res)=>{
    const id=req.params.id
    const loginname=req.session.username
    const data=await blogTable.findById(id)
    res.render('blogupdateform.ejs',{loginname,data})
}

exports.blogupdateform=async(req,res)=>{
    const id=req.params.id
    const filename=req.file.filename
    const {btitle,bdesc}=req.body
    const data=await blogTable.findByIdAndUpdate(id,{title:btitle,quotes:bdesc,img:filename})
    res.redirect('/myblogs/Succefully update')
}


