const express=require('express')//function
const app=express()
require('dotenv').config()
app.use(express.urlencoded({extended:false}))
const session=require('express-session')
const mongoose=require('mongoose')
mongoose.connect('mongodb://127.0.0.1:27017/fullstackcmsproject').then(()=>{console.log("connected to DB!!")}).catch((error)=>{console.log(error.message)})
const userRouter= require('./routers/user')
const adminRouter= require('./routers/admin')


app.use(session({
    secret:'vinaysharma',
    resave:false,
    saveUninitialized:false,
}))

app.use(userRouter)
app.use('/admin',adminRouter)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(5000,()=>{console.log('server running 5000')})
